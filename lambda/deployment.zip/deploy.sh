#!/bin/bash

# Create a temporary directory for the build
BUILD_DIR="$(mktemp -d)"
echo "Building in $BUILD_DIR"

# Copy source files
cp -r src requirements.txt "$BUILD_DIR/"

# Create and activate virtual environment
python3 -m venv "$BUILD_DIR/venv"
source "$BUILD_DIR/venv/bin/activate"

# Install dependencies
pip install -r "$BUILD_DIR/requirements.txt" -t "$BUILD_DIR/package"

# Copy source files to package directory
cp -r "$BUILD_DIR/src/"* "$BUILD_DIR/package/"

# Create deployment package
cd "$BUILD_DIR/package"
zip -r ../deployment.zip .

# Deploy to AWS Lambda
aws lambda update-function-code \
  --function-name paperpusher-chat \
  --zip-file fileb://"$BUILD_DIR/deployment.zip"

# Update environment variables
aws lambda update-function-configuration \
  --function-name paperpusher-chat \
  --environment "Variables={OPENAI_API_KEY=${OPENAI_API_KEY},PINECONE_API_KEY=${PINECONE_API_KEY},PINECONE_INDEX=${PINECONE_INDEX},SUPABASE_PROJECT_URL=${SUPABASE_PROJECT_URL},SUPABASE_SERVICE_ROLE_KEY=${SUPABASE_SERVICE_ROLE_KEY}}"

# Clean up
rm -rf "$BUILD_DIR" 